# __init__.py
# Init file for autopasscrack package